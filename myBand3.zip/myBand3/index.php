<?php

//configuration settings
require 'includes/config.php';

//initialisation
require 'includes/bootstrap.php';

// head
include 'views/head.php';

// header
include 'views/header.php';

// menu
include 'views/menu.php';

$action = isset($_GET['url']) ? $_GET['url'] : 'home';

switch ($action) {
    case 'home':
        include 'views/home.php';
        break;
    case 'articles':
//        require_once 'model/getarticles.php';

        // PAGINATION
        include 'model/getpagination.php';
        $templateParser->assign('page',$page);
        include 'model/get_data.php';
        $templateParser->assign('number_of_pages',$number_of_pages);
        $templateParser->assign('articles_list',$result_list);
//        $templateParser->display('index.tpl');


        $templateParser->assign('articles_list',$result_list);
        $templateParser->display('articles.tpl');
        break;
    case 'about':
        include 'views/about.php';
        break;
    case 'contact':
        //contact
        include 'views/contact.php';
        break;
    case 'admin':

        include 'views/admin.php';
        break;
}

// footer
include 'views/footer.php';

?>
