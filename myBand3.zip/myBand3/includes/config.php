<?php
$title = 'MyBand';

define('DB_HOST','localhost');
define('DB_NAME','myband');
define('DB_USERNAME','root');
define('DB_PASSWORD','root');

?>
