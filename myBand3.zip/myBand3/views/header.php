<body>
<div id="wrapper">
  <div id="header">
      <img src="http://logonoid.com/images/mgk-logo.png" alt="logo" style="float:left;width:50px;height:50px; margin-top:-1em; margin-left:-2em; margin-right: 1em;">
    <h1>MachineGunKelly News</h1>
    <h3>Shooting MGK news at you before anyone else</h3>
  </div>
