  <div id="body">
    <div class="articles">
      <h3>Home</h3>
      <p>MyBand van Luc Drenth, jaar 2016/2017</p>
    </div>

      <div class="articles">
          <h3>Tour information</h3>

          <table>
              <tr>
                  <th>Date</th>
                  <th>Time</th>
                  <th>State, Country</th>
                  <th>Location</th>
              </tr>
              <tr>
                  <td>30 june</td>
                  <td>19:00</td>
                  <td>France</td>
                  <td>Manisquare Festival</td>
              </tr>
              <tr>
                  <td>1 juli</td>
                  <td>19:00</td>
                  <td>Belgium</td>
                  <td>Rock Werchter</td>
              </tr>
              <tr>
                  <td>4 juli</td>
                  <td>19:00</td>
                  <td>Spain</td>
                  <td>Calle la Riviera</td>
              </tr>
              <tr>
                  <td>5 juli</td>
                  <td>19:00</td>
                  <td>Spain</td>
                  <td>Razzmatazz</td>
              </tr>
              <tr>
                  <td>7 juli</td>
                  <td>19:00</td>
                  <td>France</td>
                  <td>Courtepaille</td>
              </tr>
              <tr>
                  <td>8 juli</td>
                  <td>19:00</td>
                  <td>Switzerland</td>
                  <td>EMK-Frauenfeld-Weinfeld</td>
              </tr>
              <tr>
                  <td>9 juli</td>
                  <td>12:00</td>
                  <td>Belgium</td>
                  <td>Denmark</td>
              </tr>
              <tr>
                  <td>12 juli</td>
                  <td>19:00</td>
                  <td>Sweden</td>
                  <td>Pustervik</td>
              </tr><tr>
                  <td>13 juli</td>
                  <td>19:00</td>
                  <td>Norwegen</td>
                  <td>Tønsberg</td>
              </tr>

          </table>

      </div>
  </div>
