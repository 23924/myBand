  <div id="body">
    <div class="articles">
      <div id="contact">
      <h3><a href="mailto:23924@ma-web.nl">Contact</a> the creater of this website</h3>
      <p>Click the links above to contact the creater of this website, Luc Drenth.</p>
    </div>
    </div>
  </div>
