<?php
/* Smarty version 3.1.30, created on 2017-06-30 10:06:51
  from "/Users/lucdrenth/Desktop/BEWIJZENMAP/MGD/P1.4/myBand/myBand3/views/articles.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5956069be7da13_30079331',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'be6646b6482521538250100bfbb3e20883bd0dce' => 
    array (
      0 => '/Users/lucdrenth/Desktop/BEWIJZENMAP/MGD/P1.4/myBand/myBand3/views/articles.tpl',
      1 => 1498810009,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5956069be7da13_30079331 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="page-wrap">
<div id="body">



    <h1 id="h1page"><?php echo $_smarty_tpl->tpl_vars['page']->value;?>
</h1>

    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['articles_list']->value, 'one_article');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['one_article']->value) {
?>
        <article>
        <div class="articles">
        <h3><?php echo $_smarty_tpl->tpl_vars['one_article']->value['title'];?>
 </h3>
            <p><?php echo $_smarty_tpl->tpl_vars['one_article']->value['content'];?>
</p>
        </div>
        </article>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


    <table id="pagechanger">
      <tr><td id="left">
        <?php if ($_smarty_tpl->tpl_vars['page']->value > 1) {?>
          <a href="?url=articles&page=<?php echo $_smarty_tpl->tpl_vars['page']->value-1;?>
">Previous</a>
        <?php }?>
      </td>
      <td id="right">
        <?php if ($_smarty_tpl->tpl_vars['page']->value < $_smarty_tpl->tpl_vars['number_of_pages']->value) {?>
        <a href="?url=articles&page=<?php echo $_smarty_tpl->tpl_vars['page']->value+1;?>
">Next</a>
        <?php }?>
      </td></tr>
    </table>


</div>

</div>

<?php }
}
