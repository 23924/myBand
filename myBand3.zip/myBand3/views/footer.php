<div id="footer">
  <p>
      Copyright by Luc Drenth, 2017<br>
      <a href="mailto:23924@ma-web.nl">Contact Luc</a>
      <br>

  </p>

</div>
</div>
</body>
</html>
