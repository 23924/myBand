  <div id="nav">
    <ul>
      <li><a href="?url=home">Home</a></li>
      <li><a href="?url=articles">Articles</a></li>
      <li><a href="?url=about">About</a></li>
      <li><a href="?url=contact">Contact</a></li>
      <li><a href="?url=admin">Upload</a></li>
    </ul>
  </div>
