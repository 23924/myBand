<div id="body">
  <div class="articles">
    <h3>About Machine Gun Kelly</h3>
      <img src="https://i.ytimg.com/vi/cI-jEwWG5V0/hqdefault.jpg" alt="MGK" style="width:300px;height:300px;margin-right:0.5em;float:left;border:1px solid white;">
      <div><iframe src="https://www.youtube.com/embed/dOMsI7p_HQ4?ecver=2" width="300" height="300" frameborder="1px solid white" style="" allowfullscreen></iframe></div>

      <p>Colson Baker (born April 22, 1990), better known by his stage names MGK and Machine Gun Kelly, is an American rapper and actor, from Cleveland, Ohio. MGK embarked on a musical career as a teenager, releasing a mixtape in 2006. He would then go on to release four further mixtapes. <br><br>

      MGK then secured a recording contract with Bad Boy and Interscope Records in 2011. His major label debut album, Lace Up, was released in October 2012 to positive response from critics. The record contained the singles "Wild Boy", "Invincible", "Stereo", and "Hold On (Shut Up)", and debuted at number four on the US Billboard 200 chart; it was later confirmed to have sold more than 178,000 copies. In early 2015, he released the singles "Till I Die" and "A Little More" for his second studio album, General Admission, which released in October 2015, and also debuted at number four in the US. The album incorporated darker tones, rap rock, R and B, and storytelling. <br> <br>

      MGK has also appeared in various films, starring in Beyond the Lights, as Kid Culprit. He would then star in Roadies as Wesley (a.k.a. Wes), before being cast in lead roles in Viral, Punk's Dead: SLC Punk 2 and Nerve.</p>
  </div>

    <div class="articles">
        <h3>About this website</h3>
        <p>This is a schoolproject (myband) created by Luc Drenth in schoolyear 2016, 2017 of mediadeveloper year 1.</p>
    </div>
</div>
