<<?php

$dbc = mysqli_connect(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_NAME) or die ('cant connect to the database');


// Aantal items per pagina
$results_per_page = 4;

// aantal pagina's berekenen
$query = "SELECT * FROM articles";
$result = mysqli_query($dbc,$query) or die ('Error querying');
$number_of_results = mysqli_num_rows($result);
$number_of_pages = ceil($number_of_results / $results_per_page);

// Huidige pagina checken
if(!isset($_GET['page'])){
  $page = 1;
} else {
  $page = $_GET['page'];
}

// Eerste item van query bepalen
$limit_starting_number = ($page - 1) * $results_per_page;


 ?>
